<?php

return [
    'previous' => '&laquo; Précédent',
    'next' => 'Suivant &raquo;',
];
