<?php
namespace App\Repositories\Exceptions;

use Exception;

class RepositoryException extends Exception
{
    //
}
