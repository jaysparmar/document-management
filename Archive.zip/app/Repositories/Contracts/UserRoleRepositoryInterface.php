<?php

namespace App\Repositories\Contracts;
use App\Repositories\Contracts\BaseRepositoryInterface;

interface UserRoleRepositoryInterface extends BaseRepositoryInterface
{

}
