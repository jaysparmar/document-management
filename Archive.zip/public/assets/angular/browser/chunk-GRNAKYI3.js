var t=function(f){return f[f.Office=0]="Office",f[f.Pdf=1]="Pdf",f[f.Image=2]="Image",f[f.Text=3]="Text",f[f.Audio=4]="Audio",f[f.Video=5]="Video",f[f.Other=6]="Other",f}(t||{});export{t as a};
