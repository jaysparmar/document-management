import{a}from"./chunk-NXPK56UL.js";import"./chunk-2WH2EVR6.js";export default a();
