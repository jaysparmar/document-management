<?php

return [
    'APP_VERSION' => '4.0.0',
];
